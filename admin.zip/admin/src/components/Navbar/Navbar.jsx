import React from 'react';
import { assets } from './../../assets/assets';

const Navbar = () => {
  return (
    <header className="w-full flex items-center justify-between px-6 py-4 bg-white shadow-sm border-b border-gray-200">
      <div className="flex items-center gap-3">
        <img src={assets.logo} alt="Foodify Logo" className="h-9 w-9" />
        <h1 className="text-2xl font-bold text-red-500 tracking-tight hidden sm:block">
          Foodify <span className="text-sm font-medium text-gray-500 ml-1">Admin Panel</span>
        </h1>
      </div>

      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-600 hidden sm:block">Admin</span>
        <img
          src={assets.profile_image}
          alt="Profile"
          className="h-10 w-10 rounded-full object-cover border-2 border-red-200 hover:scale-105 transition duration-200"
        />
      </div>
    </header>
  );
};

export default Navbar;
